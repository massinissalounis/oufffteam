/*
 * Carte de réception de balise
 *
 * Christophe Le Lann <contact@totofweb.net>
 * http://www.totofweb.net/robots-projet-67.html
 */

#ifndef DELAIS_H
#define DELAIS_H

//-----------------------------
// Prototypes
//-----------------------------

void delay_ms(unsigned int duree);

#endif
